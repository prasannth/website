var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
 // res.io.emit("socketToMe", "users");
  res.send('respond with a resource.');
});

module.exports = router;


// var express = require('express');
// var router = express.Router();
// var http = require('http').Server(router);
// var io = require('socket.io')(http);
// var path = require('path');


// router.get('/', function(req, res) {
//    // res.sendfile('index.html');
//     res.sendFile(path.join(__dirname, '../views/socketTest.html'));
// });



// var roomno = 1;
// io.on('connection', function(socket) {
   
//    //Increase roomno 2 clients are present in a room.
//    if(io.nsps['/'].adapter.rooms["room-"+roomno] && io.nsps['/'].adapter.rooms["room-"+roomno].length > 1) roomno++;
//    socket.join("room-"+roomno);

//    //Send this event to everyone in the room.
//    io.sockets.in("room-"+roomno).emit('connectToRoom', "You are in room no. "+roomno);
// })


// module.exports = router;