var express = require('express');
var router = express.Router();
var path = require('path');
// const { Pool, Client } = require('pg')
// // DB_HOST=localhost
// // DB_DATABASE=amenextdb
// // DB_USERNAME=amenext
// // DB_PASSWORD=#$%^8#$g6deA7$6

// const client = new Client({
// user: 'amenext',
// password: '#$%^8#$g6deA7$6',
// host: 'localhost',
// database: 'amenextdb',
// })



// client.connect()



// client.query('LISTEN order_trigger')

// client.on('notification', msg => {
//   console.log(msg.channel) // foo
//   console.log(msg.payload) // bar!
// })

/* GET home page. */
router.get('/', function(req, res, next) {
  // res.render('index', { title: 'Express' });
//res.send("success");
   res.sendFile(path.join(__dirname, '../views/socketTest.html'));
});


module.exports = router;
