require('newrelic');
var express = require('express');
var path = require('path');
// var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var routes = require('./routes/index');
var users = require('./routes/users');

var momentJs = require('moment');


// for api call 
var axios = require('axios');

// firebase sever key
var _fcmServerKey = 'AAAAzIl1AiA:APA91bGu-ThfOepY30smrHk4Vm-ZkoaF7RI4MeMlQXYBGEn9-QYe_VM4MjuZziLhKewS6L6QdZjMHpZOS6T-wco644NgtsF9DRsptg8BFcPafThGNmZDPg4uMYrvM3LWkZq0YuY2mrJt';

var app = express();


// setup serve to listen  
var server = require('http').createServer(app);
var io = require('socket.io')(server);

// Listen to port
server.listen(3030);
console.log("Listening to 3030");


const { Pool, Client } = require('pg')
// DB_HOST=localhost
// DB_DATABASE=amenextdb
// DB_USERNAME=amenext
// DB_PASSWORD=#$%^8#$g6deA7$6


// Restaurant db config 
const client = new Client({
  user: 'postgres',
  password: 'password',
  host: 'localhost',
  database: 'restdb',
})
client.connect()



//sequelize
const logData = require("./src/model/OrderLogModel");
const commonDatabase = require("./src/database/database.js");

commonDatabase.authenticate()
  .then((response) => {
    console.log("--------------------------\n Database Connected\n--------");

  })
  .catch(error => {
    console.log("--------------------------\n Database Error\n--------");
    console.log(error)
  })


// listen to port
client.query('LISTEN order_trigger')


// incoming notification from psql trigger function
client.on('notification', message => {
  console.log(message.channel) // foo
  console.log(message.payload) // bar!

  // Alert Outlet application on listener id
  io.emit(JSON.parse(message.payload).outlet_id, message.payload)

  var _outletId = [];
  _outletId.push(JSON.parse(message.payload).outlet_id);
  const _payloadData = JSON.parse(message.payload);

  // get device token 
  getDeviceTokenApi(_outletId, _payloadData)

  // log in common database
  addLogToCommonDatabase(_payloadData)

})

function addLogToCommonDatabase(_payloadData) {


  logData.findAll({
    where: {
      order_id: _payloadData.order_id,
      service_type: 5
    }
  })
    .then((response) => {
      if (response.length == 0) {
        insertPayload(_payloadData)
      } else {
        updatePayload(_payloadData)
      }
    })
    .catch((error) => {
      console.log(error)
    })




}

function updatePayload(_payloadData) {

  var requestData = JSON.stringify(_payloadData);
  var booking_date = new Date(momentJs(JSON.stringify(requestData.booking_date, 'YYYY-MM-DD')).format('YYYY-MM-DD'));

  logData.update(
    {
      outlet_id: _payloadData.outlet_id,
      vendor_id: _payloadData.vendor_id,
      customer_id: _payloadData.customer_id,
      outlet_name: _payloadData.outlet_name,
      payment_mode: _payloadData.payment_id,
      order_status: _payloadData.order_status,
      total_price: _payloadData.total_amount,
      delivery_charge: _payloadData.delivery_charge,
      wallet_used: _payloadData.wallet_used,
      service_tax: _payloadData.service_tax,
      service_type: _payloadData.service_type,
      vendor_logo: _payloadData.vendor_logo,
      listener_id: _payloadData.listener_id,
      customer_name: _payloadData.customer_name,
      order_attachment: _payloadData.order_attachment,
      digital_signature: _payloadData.digital_signature,
      order_comments: _payloadData.order_comments,
      payment_gateway_commission: _payloadData.payment_gateway_commission,
      invoice_id: _payloadData.invoice_id,
      coupon_type: _payloadData.coupon_type,
      coupon_amount: _payloadData.coupon_amount,
      coupon_id: _payloadData.coupon_id,
      refund_status: _payloadData.refund_status,
      delivery_status: _payloadData.delivery_status,
      order_key: _payloadData.order_key,
      modified_by: _payloadData.modified_by,
      order_accepted_by: _payloadData.order_accepted_by,
      service_id: _payloadData.service_id,
      service_name: _payloadData.service_name,
      booking_time: _payloadData.booking_time,
      booking_date: booking_date,
      group_duration: _payloadData.group_duration,
      staff_name: _payloadData.staff_name,
      service_details: _payloadData.service_details,
      staff_id: _payloadData.staff_id,
      address_id: _payloadData.address_id,
      payment_id: _payloadData.payment_id,
      vendor_name: _payloadData.vendor_name,
      updated_at: new Date()
    },
    {
      where: {
        order_id: _payloadData.order_id
      }
    }
  )
}


function insertPayload(_payloadData) {


  var requestData = JSON.stringify(_payloadData);
  var booking_date = new Date(momentJs(JSON.stringify(requestData.booking_date, 'YYYY-MM-DD')).format('YYYY-MM-DD'))

  logData.create({
    order_id: _payloadData.order_id,
    outlet_id: _payloadData.outlet_id,
    vendor_id: _payloadData.vendor_id,
    customer_id: _payloadData.customer_id,
    outlet_name: _payloadData.outlet_name,
    payment_mode: _payloadData.payment_id,
    order_status: _payloadData.order_status,
    total_price: _payloadData.total_amount,
    delivery_charge: _payloadData.delivery_charge,
    wallet_used: _payloadData.wallet_used,
    service_tax: _payloadData.service_tax,
    service_type: _payloadData.service_type,
    vendor_logo: _payloadData.vendor_logo,
    listener_id: _payloadData.listener_id,
    customer_name: _payloadData.customer_name,
    order_attachment: _payloadData.order_attachment,
    digital_signature: _payloadData.digital_signature,
    order_comments: _payloadData.order_comments,
    payment_gateway_commission: _payloadData.payment_gateway_commission,
    invoice_id: _payloadData.invoice_id,
    coupon_type: _payloadData.coupon_type,
    coupon_amount: _payloadData.coupon_amount,
    coupon_id: _payloadData.coupon_id,
    refund_status: _payloadData.refund_status,
    delivery_status: _payloadData.delivery_status,
    order_key: _payloadData.order_key,
    modified_by: _payloadData.modified_by,
    order_accepted_by: _payloadData.order_accepted_by,
    service_id: _payloadData.service_id,
    service_name: _payloadData.service_name,
    booking_time: _payloadData.booking_time,
    booking_date: booking_date,
    group_duration: _payloadData.group_duration,
    staff_name: _payloadData.staff_name,
    service_details: _payloadData.service_details,
    staff_id: _payloadData.staff_id,
    address_id: _payloadData.address_id,
    payment_id: _payloadData.payment_id,
    vendor_name: _payloadData.vendor_name,
    created_at: new Date()
  })
    .then(response => {
      console.log("--------------------------\n Create new Log\n--------");
      console.log('Response ', JSON.stringify(response));
    })
    .catch(error => {
      console.log("--------------------------\n Create New Log Error\n--------");
      console.log(error)
    })

}




function getDeviceTokenApi(_outletId, _payloadData) {


  // get device to ken for the push notification
  axios.get('http://user.brozapp.com/api/getDeviceToken?outletId=' + _outletId + '&userType=0')
    .then(function (response) {

      // get send push notification to all the device token
      response.data.responseData.forEach(element => {

        // 1 = Initiated
        // 10 = Processed
        // 11 = Cancelled
        // 12 = Delivered
        // 14 = Shipped
        // 16 = Returned
        // 18 = Packed
        // 19 = Dispatched
        // 31 = Driver Accept
        // 32 = Driver arrived outlet
        // 33 = CashIn
        // 34 = Sales Person Assigned
        // 35 = Driver Assign
        // 37 = Reached Customer Place

        // var data = JSON.stringify({
        //   "to": element.deviceToken,
        //   "notification": {
        //     "title": _payloadData.outlet_name,
        //     "body": _payloadData.customer_name +
        //       ' | ' + _payloadData.total_amount + ' AED',
        //     "image": "Notification Image"
        //   },
        //   "content_available": true,
        //   "priority": "high",
        //   "apns": {
        //     "headers": {
        //       "apns-priority": "10"
        //     }
        //   }
        // });
        // sendPushNotification(data);
        // if (_payloadData.order_status == 1) {

        // }

        if (_payloadData.order_status != 8) {
          var data = JSON.stringify({
            "to": element.deviceToken,
            "notification": {
              "title": _payloadData.outlet_name,
              "body": _payloadData.customer_name +
                '| ' + _payloadData.total_amount,
              "image": "Notification Image"
            },
            "content_available": true,
            "priority": "high",
            "apns": {
              "headers": {
                "apns-priority": "10"
              }
            }
          });
          sendPushNotification(data);
        }

        // if (_payloadData.order_status == 10) {
        //   var data = JSON.stringify({
        //     "to": element.deviceToken,
        //     "notification": {
        //       "title": _payloadData.outlet_name,
        //       "body": _payloadData.customer_name +
        //         '| ' + _payloadData.total_amount,
        //       "image": "Notification Image"
        //     },
        //     "content_available": true,
        //     "priority": "high",
        //     "apns": {
        //       "headers": {
        //         "apns-priority": "10"
        //       }
        //     }
        //   });
        //   sendPushNotification(data);
        // }

        // if (_payloadData.order_status == 11) {
        //   var data = JSON.stringify({
        //     "to": element.deviceToken,
        //     "notification": {
        //       "title": _payloadData.outlet_name,
        //       "body": _payloadData.customer_name +
        //         '| ' + _payloadData.total_amount,
        //       "image": "Notification Image"
        //     },
        //     "content_available": true,
        //     "priority": "high",
        //     "apns": {
        //       "headers": {
        //         "apns-priority": "10"
        //       }
        //     }
        //   });
        //   sendPushNotification(data);
        // }

        // if (_payloadData.order_status == 12) {
        //   var data = JSON.stringify({
        //     "to": element.deviceToken,
        //     "notification": {
        //       "title": _payloadData.outlet_name,
        //       "body": _payloadData.customer_name +
        //         '| ' + _payloadData.total_amount,
        //       "image": "Notification Image"
        //     },
        //     "content_available": true,
        //     "priority": "high",
        //     "apns": {
        //       "headers": {
        //         "apns-priority": "10"
        //       }
        //     }
        //   });
        //   sendPushNotification(data);
        // }

        // if (_payloadData.order_status == 14) {
        //   var data = JSON.stringify({
        //     "to": element.deviceToken,
        //     "notification": {
        //       "title": _payloadData.outlet_name,
        //       "body": _payloadData.customer_name +
        //         '| ' + _payloadData.total_amount,
        //       "image": "Notification Image"
        //     },
        //     "content_available": true,
        //     "priority": "high",
        //     "apns": {
        //       "headers": {
        //         "apns-priority": "10"
        //       }
        //     }
        //   });
        //   sendPushNotification(data);
        // }
        // if (_payloadData.order_status == 16) {
        //   var data = JSON.stringify({
        //     "to": element.deviceToken,
        //     "notification": {
        //       "title": "Order Returned",
        //       "body": " Order Returned @" + _payloadData.outlet_name +
        //         '| #' + _payloadData.order_id +
        //         '| Customer Name: ' + _payloadData.customer_name +
        //         '| Order Cost: ' + _payloadData.total_amount,

        //       "image": "Notification Image"
        //     },
        //     "content_available": true,
        //     "priority": "high",
        //     "apns": {
        //       "headers": {
        //         "apns-priority": "10"
        //       }
        //     }
        //   });
        //   sendPushNotification(data);
        // }
        // if (_payloadData.order_status == 18) {
        //   var data = JSON.stringify({
        //     "to": element.deviceToken,
        //     "notification": {
        //       "title": "Order Packed",
        //       "body": " Order Packed @" + _payloadData.outlet_name +
        //         '| #' + _payloadData.order_id +
        //         '| Customer Name: ' + _payloadData.customer_name +
        //         '| Order Cost: ' + _payloadData.total_amount,

        //       "image": "Notification Image"
        //     },
        //     "content_available": true,
        //     "priority": "high",
        //     "apns": {
        //       "headers": {
        //         "apns-priority": "10"
        //       }
        //     }
        //   });
        //   sendPushNotification(data);
        // }
        // if (_payloadData.order_status == 19) {
        //   var data = JSON.stringify({
        //     "to": element.deviceToken,
        //     "notification": {
        //       "title": "Order Dispatched",
        //       "body": " Order Dispatched @" + _payloadData.outlet_name +
        //         '| #' + _payloadData.order_id +
        //         '| Customer Name: ' + _payloadData.customer_name +
        //         '| Order Cost: ' + _payloadData.total_amount,

        //       "image": "Notification Image"
        //     },
        //     "content_available": true,
        //     "priority": "high",
        //     "apns": {
        //       "headers": {
        //         "apns-priority": "10"
        //       }
        //     }
        //   });
        //   sendPushNotification(data);
        // }
        // if (_payloadData.order_status == 31) {
        //   var data = JSON.stringify({
        //     "to": element.deviceToken,
        //     "notification": {
        //       "title": "Driver Accept",
        //       "body": " Driver Accept @" + _payloadData.outlet_name +
        //         '| #' + _payloadData.order_id +
        //         '| Customer Name: ' + _payloadData.customer_name +
        //         '| Order Cost: ' + _payloadData.total_amount,

        //       "image": "Notification Image"
        //     },
        //     "content_available": true,
        //     "priority": "high",
        //     "apns": {
        //       "headers": {
        //         "apns-priority": "10"
        //       }
        //     }
        //   });
        //   sendPushNotification(data);
        // }
        // if (_payloadData.order_status == 32) {
        //   var data = JSON.stringify({
        //     "to": element.deviceToken,
        //     "notification": {
        //       "title": "Driver Arrived at Outlet",
        //       "body": " Driver Arrived at Outlet @" + _payloadData.outlet_name +
        //         '| #' + _payloadData.order_id +
        //         '| Customer Name: ' + _payloadData.customer_name +
        //         '| Order Cost: ' + _payloadData.total_amount,

        //       "image": "Notification Image"
        //     },
        //     "content_available": true,
        //     "priority": "high",
        //     "apns": {
        //       "headers": {
        //         "apns-priority": "10"
        //       }
        //     }
        //   });
        //   sendPushNotification(data);
        // }
        // if (_payloadData.order_status == 33) {
        //   var data = JSON.stringify({
        //     "to": element.deviceToken,
        //     "notification": {
        //       "title": "Order Completed",
        //       "body": " Order Completed @" + _payloadData.outlet_name +
        //         '| #' + _payloadData.order_id +
        //         '| Customer Name: ' + _payloadData.customer_name +
        //         '| Order Cost: ' + _payloadData.total_amount,

        //       "image": "Notification Image"
        //     },
        //     "content_available": true,
        //     "priority": "high",
        //     "apns": {
        //       "headers": {
        //         "apns-priority": "10"
        //       }
        //     }
        //   });
        //   sendPushNotification(data);
        // }
        // if (_payloadData.order_status == 34) {
        //   var data = JSON.stringify({
        //     "to": element.deviceToken,
        //     "notification": {
        //       "title": "Sales Person Assigned",
        //       "body": " Sales Person Assigned @" + _payloadData.outlet_name +
        //         '| #' + _payloadData.order_id +
        //         '| Customer Name: ' + _payloadData.customer_name +
        //         '| Order Cost: ' + _payloadData.total_amount,

        //       "image": "Notification Image"
        //     },
        //     "content_available": true,
        //     "priority": "high",
        //     "apns": {
        //       "headers": {
        //         "apns-priority": "10"
        //       }
        //     }
        //   });
        //   sendPushNotification(data);
        // }

        // if (_payloadData.order_status == 35) {
        //   var data = JSON.stringify({
        //     "to": element.deviceToken,
        //     "notification": {
        //       "title": "Driver Assign",
        //       "body": " Driver Assign @" + _payloadData.outlet_name +
        //         '| #' + _payloadData.order_id +
        //         '| Customer Name: ' + _payloadData.customer_name +
        //         '| Order Cost: ' + _payloadData.total_amount,

        //       "image": "Notification Image"
        //     },
        //     "content_available": true,
        //     "priority": "high",
        //     "apns": {
        //       "headers": {
        //         "apns-priority": "10"
        //       }
        //     }
        //   });
        //   sendPushNotification(data);
        // }

        // if (_payloadData.order_status == 37) {
        //   var data = JSON.stringify({
        //     "to": element.deviceToken,
        //     "notification": {
        //       "title": "Driver Reached Customer Place",
        //       "body": " Driver Reached Customer Place @" + _payloadData.outlet_name +
        //         '| #' + _payloadData.order_id +
        //         '| Customer Name: ' + _payloadData.customer_name +
        //         '| Order Cost: ' + _payloadData.total_amount,

        //       "image": "Notification Image"
        //     },
        //     "content_available": true,
        //     "priority": "high",
        //     "apns": {
        //       "headers": {
        //         "apns-priority": "10"
        //       }
        //     }
        //   });
        //   sendPushNotification(data);
        // }
      });
    })
    .catch(function (error) {
      console.log(error);
    });

}


function sendPushNotification(data) {
  console.log('\n Send Push Notification')

  // gcm configuration for post 
  var config = {
    method: 'post',
    url: 'https://fcm.googleapis.com/fcm/send',
    headers: {
      'Authorization': 'key=' + _fcmServerKey,
      'Content-Type': 'application/json'
    },
    data: data
  };

  axios(config)
    .then(function (response) {
      console.log('Axios GCM response', JSON.stringify(response.data));
    })
    .catch(function (error) {
      console.log(error);
    });

  // var message = new gcm.Message({
  //   // collapse_key: "type_a",
  //   notification: {
  //     body: "Body of Your Notification",
  //     title: "Title of Your Notification"
  //   }
  //   // ,
  //   // data: {
  //   //   body: "Body of Your Notification in Data",
  //   //   title: "Title of Your Notification in Title",
  //   //   key_1: "Value for key_1",
  //   //   key_2: "Value for key_2"
  //   // }
  // });

  // sender.send(message, { registrationTokens: _registrationTokens }, function (err, response) {
  //   if (err) { console.error(err); }
  //   else { console.log(response); }
  // });

}


//var socket = 

// var server = app.listen(3030);
// // var http = require('http').Server(app);
// var io = require('socket.io')(server);



// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
// app.use(function(req, res, next){
//   res.io = io;
//   next();
// });
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', routes);
app.use('/users', users);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
  app.use(function (err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
      message: err.message,
      error: err
    });
  });
}

io.on('connection', function (socket) {
  console.log("connection count" + io.engine.clientsCount);
  console.log('%j - %j \n\n\n', socket.handshake.time, socket.handshake.headers['user-agent']);
  // console.log("connected"+socket.handshake);
  // socket.on('chat message', function(message){
  //   io.emit('chat message', message);
  // });
});


// production error handler
// no stacktraces leaked to user
app.use(function (err, req, res, next) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});
