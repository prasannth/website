const { Sequelize, DataTypes } = require('sequelize');
const database = require('../database/database');


const OrderLog = database.define('Logs', {
    id: {
        type: DataTypes.BIGINT,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true
    },
    order_id: DataTypes.INTEGER,
    outlet_id: DataTypes.INTEGER,
    vendor_id: DataTypes.INTEGER,
    customer_id: DataTypes.INTEGER,
    outlet_name: DataTypes.CHAR(255),
    payment_mode: DataTypes.INTEGER,
    order_status: DataTypes.INTEGER,
    total_price: DataTypes["DOUBLE PRECISION"],
    delivery_charge: DataTypes["DOUBLE PRECISION"],
    wallet_used: DataTypes.CHAR,
    service_tax: DataTypes["DOUBLE PRECISION"],
    service_type: DataTypes.INTEGER,
    vendor_logo: DataTypes.CHAR,
    listener_id: DataTypes.INTEGER,
    customer_name: DataTypes.CHAR,
    order_attachment: DataTypes.CHAR,
    digital_signature: DataTypes.CHAR,
    order_comments: DataTypes.CHAR,
    payment_gateway_commission: DataTypes.INTEGER,
    invoice_id: DataTypes.INTEGER,
    coupon_type: DataTypes.CHAR,
    coupon_amount: DataTypes.INTEGER,
    coupon_id: DataTypes.INTEGER,
    refund_status: DataTypes.CHAR,
    delivery_status: DataTypes.CHAR,
    order_key: DataTypes.CHAR,
    modified_by: DataTypes.CHAR,
    order_accepted_by: DataTypes.CHAR,
    service_id: DataTypes.CHAR,
    service_name: DataTypes.CHAR,
    booking_time: DataTypes.CHAR,
    booking_date: DataTypes.DATEONLY,
    group_duration: DataTypes.CHAR,
    staff_name: DataTypes.CHAR,
    service_details: DataTypes.CHAR,
    staff_id: DataTypes.CHAR,
    address_id: DataTypes.INTEGER,
    payment_id: DataTypes.INTEGER,
    vendor_name: DataTypes.CHAR,
    service_type: {
        type: DataTypes.INTEGER,
        defaultValue: 5
    },
    created_at: {
        type: DataTypes.DATE
    }, updated_at: {
        type: DataTypes.DATE
    }
}, {
    tableName: "broz_orders_new",
    timestamps: false
});

module.exports = OrderLog;