const Sequelize = require('sequelize');

// Option 2: Passing parameters separately (other dialects)
module.exports = new Sequelize('userdb', 'postgres', 'password', {
    host: '13.127.223.28',
    dialect: 'postgres',
});

